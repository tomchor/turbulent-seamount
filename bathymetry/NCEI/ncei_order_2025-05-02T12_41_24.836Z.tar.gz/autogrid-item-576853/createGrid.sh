mbgrid -E60/0.0! -Imblist.mbf -N -Ooutput -P1 -R-65.76080/-65.05493/39.06371/39.69846 -A2 -V -F1 >> output.log 2>&1
grdreformat output.grd output.grd=ni
