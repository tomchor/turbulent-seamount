#script for creating a map
# Make color image
grdimage output.grd -JM7.0h -R-65.7608/-65.05493/39.06371/39.69846 -Coutput.cpt -P -Xc -Yc -K -V > map.ps 2>> output.log

# Make contour plot
grdcontour output.grd -JM7.0h -R-65.7608/-65.05493/39.06371/39.69846 -C250 -A1250 -L-5445.0/4760.0 -Wa1p -P -K -O -V >> map.ps 2>> output.log

# add coastline
pscoast -JM7.0h -R-65.7608/-65.05493/39.06371/39.69846 -Df -W3p,gray  -K -O -V >> map.ps 2>> output.log

# Make basemap
psbasemap -JM7.0h -R-65.7608/-65.05493/39.06371/39.69846 -B8m/8m:."AutoGrid": -P -K -O -V>> map.ps 2>> output.log

# Make color scale
psscale -Coutput.cpt -D3.0083852250i/-0.5i/6.0i/0.15ih -B":Topography (m):" -P -O -V >> map.ps 	2>> output.log
	